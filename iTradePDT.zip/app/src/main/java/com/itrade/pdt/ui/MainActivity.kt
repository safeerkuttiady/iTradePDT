package com.itrade.pdt.ui

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.itrade.pdt.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnImport.setOnClickListener {
            Toast.makeText(this, "Import Module (Next Phase)", Toast.LENGTH_SHORT).show()
        }

        binding.btnGRN.setOnClickListener {
            Toast.makeText(this, "GRN Module (Next Phase)", Toast.LENGTH_SHORT).show()
        }

        binding.btnExport.setOnClickListener {
            Toast.makeText(this, "Export Module (Next Phase)", Toast.LENGTH_SHORT).show()
        }
    }
}
