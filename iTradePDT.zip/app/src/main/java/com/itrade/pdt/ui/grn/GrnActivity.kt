package com.itrade.pdt.ui.grn

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.itrade.pdt.data.AppDatabase
import com.itrade.pdt.data.entity.GRNHeader
import com.itrade.pdt.data.entity.GRNItem
import com.itrade.pdt.data.entity.Product
import com.itrade.pdt.databinding.ActivityGrnBinding
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class GrnActivity : AppCompatActivity() {
    private lateinit var binding: ActivityGrnBinding
    private val currentItems = mutableListOf<GrnItemDisplay>()
    private lateinit var adapter: GrnItemAdapter
    private var lastLookedUpProduct: Product? = null
    
    private val barcodeLauncher = registerForActivityResult(ScanContract()) { result ->
        if (result.contents != null) {
            binding.etBarcode.setText(result.contents)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGrnBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()

        binding.btnScan.setOnClickListener {
            val options = ScanOptions()
            options.setDesiredBarcodeFormats(ScanOptions.ALL_CODE_TYPES)
            options.setPrompt("Scan a barcode")
            options.setBeepEnabled(true)
            barcodeLauncher.launch(options)
        }

        binding.etBarcode.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                lookupProduct(s.toString())
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        binding.btnAddItem.setOnClickListener {
            addItemToList()
        }

        binding.btnSaveGRN.setOnClickListener {
            saveGRN()
        }
    }

    private fun setupRecyclerView() {
        adapter = GrnItemAdapter(currentItems) { position ->
            currentItems.removeAt(position)
            adapter.notifyItemRemoved(position)
            adapter.notifyItemRangeChanged(position, currentItems.size)
        }
        binding.rvGrnItems.layoutManager = LinearLayoutManager(this)
        binding.rvGrnItems.adapter = adapter
    }

    private fun lookupProduct(barcode: String) {
        if (barcode.length < 3) {
            lastLookedUpProduct = null
            binding.tvItemName.text = "Item Name: -"
            return
        }
        lifecycleScope.launch(Dispatchers.IO) {
            val product = AppDatabase.getDatabase(this@GrnActivity).productDao().getProductByBarcode(barcode)
            withContext(Dispatchers.Main) {
                lastLookedUpProduct = product
                binding.tvItemName.text = "Item Name: ${product?.name ?: "Not Found"}"
            }
        }
    }

    private fun addItemToList() {
        val barcode = binding.etBarcode.text.toString()
        val qtyString = binding.etQty.text.toString()
        val qty = qtyString.toDoubleOrNull() ?: 0.0
        
        if (barcode.isNotEmpty() && qty > 0) {
            val itemName = lastLookedUpProduct?.name ?: "Unknown Product"
            val item = GRNItem(grnId = 0, barcode = barcode, qty = qty)
            
            currentItems.add(0, GrnItemDisplay(item, itemName))
            adapter.notifyItemInserted(0)
            binding.rvGrnItems.scrollToPosition(0)

            Toast.makeText(this, "Added: $itemName", Toast.LENGTH_SHORT).show()
            binding.etBarcode.text?.clear()
            binding.etQty.text?.clear()
            lastLookedUpProduct = null
        } else {
            Toast.makeText(this, "Enter valid barcode and quantity", Toast.LENGTH_SHORT).show()
        }
    }

    private fun saveGRN() {
        val ref = binding.etReference.text.toString()
        if (ref.isEmpty() || currentItems.isEmpty()) {
            Toast.makeText(this, "Enter reference and add items", Toast.LENGTH_SHORT).show()
            return
        }

        lifecycleScope.launch(Dispatchers.IO) {
            val db = AppDatabase.getDatabase(this@GrnActivity)
            val headerId = db.grnDao().insertHeader(GRNHeader(date = System.currentTimeMillis(), reference = ref))
            val itemsToSave = currentItems.map { it.item.copy(grnId = headerId.toInt()) }
            db.grnDao().insertItems(itemsToSave)
            
            withContext(Dispatchers.Main) {
                Toast.makeText(this@GrnActivity, "GRN Saved Successfully", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }
}
