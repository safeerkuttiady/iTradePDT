package com.itrade.pdt.ui.importing

import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.itrade.pdt.data.AppDatabase
import com.itrade.pdt.data.entity.Product
import com.itrade.pdt.databinding.ActivityImportBinding
import com.itrade.pdt.util.CsvParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader

class ImportActivity : AppCompatActivity() {
    private lateinit var binding: ActivityImportBinding
    private val previewList = mutableListOf<Product>()
    private var fullList = mutableListOf<Product>()
    private lateinit var adapter: ProductAdapter

    private val filePicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let { parseFile(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityImportBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        
        binding.btnSelectFile.setOnClickListener {
            filePicker.launch("*/*")
        }

        binding.btnSaveToDb.setOnClickListener {
            saveToDatabase()
        }
    }

    private fun setupRecyclerView() {
        adapter = ProductAdapter(previewList)
        binding.rvPreview.layoutManager = LinearLayoutManager(this)
        binding.rvPreview.adapter = adapter
    }

    private fun parseFile(uri: Uri) {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val inputStream = contentResolver.openInputStream(uri)
                val reader = BufferedReader(InputStreamReader(inputStream))
                val products = mutableListOf<Product>()
                
                reader.forEachLine { line ->
                    CsvParser.parseLine(line)?.let { products.add(it) }
                }
                
                fullList = products
                
                withContext(Dispatchers.Main) {
                    previewList.clear()
                    previewList.addAll(products.take(50)) // Show up to 50 for preview
                    adapter.notifyDataSetChanged()
                    
                    Toast.makeText(this@ImportActivity, "Loaded ${products.size} items", Toast.LENGTH_SHORT).show()
                    binding.btnSaveToDb.isEnabled = products.isNotEmpty()
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@ImportActivity, "Error: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun saveToDatabase() {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val db = AppDatabase.getDatabase(this@ImportActivity)
                // Optional: db.productDao().deleteAll() // Clear old data if needed
                db.productDao().insertAll(fullList)
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@ImportActivity, "Saved ${fullList.size} products to database", Toast.LENGTH_SHORT).show()
                    finish()
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@ImportActivity, "Database Error: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }
}
