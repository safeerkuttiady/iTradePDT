package com.itrade.pdt.util

import com.itrade.pdt.data.entity.Product

object CsvParser {
    fun parseLine(line: String): Product? {
        // Remove § and split by comma, handling quotes
        val cleanLine = line.trim().removePrefix("§")
        if (cleanLine.isEmpty()) return null

        // Simple regex to split by comma outside of quotes
        val regex = ",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)".toRegex()
        val parts = cleanLine.split(regex).map { it.trim().removeSurrounding("\"") }

        return if (parts.size >= 4) {
            Product(
                barcode = parts[0],
                name = parts[1],
                costPrice = parts[2].toDoubleOrNull() ?: 0.0,
                sellingPrice = parts[3].toDoubleOrNull() ?: 0.0
            )
        } else {
            null
        }
    }
}
