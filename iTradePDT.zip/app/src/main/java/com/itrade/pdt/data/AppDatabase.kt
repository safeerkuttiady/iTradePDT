package com.itrade.pdt.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.itrade.pdt.data.dao.GRNDao
import com.itrade.pdt.data.dao.ProductDao
import com.itrade.pdt.data.entity.GRNHeader
import com.itrade.pdt.data.entity.GRNItem
import com.itrade.pdt.data.entity.Product

@Database(entities = [Product::class, GRNHeader::class, GRNItem::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun productDao(): ProductDao
    abstract fun grnDao(): GRNDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "itrade_pdt_db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
