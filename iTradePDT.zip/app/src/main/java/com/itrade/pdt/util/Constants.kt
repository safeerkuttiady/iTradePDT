package com.itrade.pdt.util

object Constants {
    const val DB_NAME = "itrade_db"
}
