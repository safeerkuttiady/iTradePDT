package com.itrade.pdt.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "grn_items")
data class GRNItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val grnId: Int,
    val barcode: String,
    val qty: Double
)
