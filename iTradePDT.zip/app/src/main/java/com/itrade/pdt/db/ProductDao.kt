package com.itrade.pdt.db

import androidx.room.*

@Dao
interface ProductDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(product: Product)

    @Query("SELECT * FROM Product WHERE barcode = :barcode LIMIT 1")
    fun getByBarcode(barcode: String): Product?

    @Query("SELECT * FROM Product")
    fun getAll(): List<Product>
}
