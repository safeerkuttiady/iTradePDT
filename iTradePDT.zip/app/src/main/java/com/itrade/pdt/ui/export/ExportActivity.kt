package com.itrade.pdt.ui.export

import android.os.Bundle
import android.os.Environment
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.itrade.pdt.data.AppDatabase
import com.itrade.pdt.databinding.ActivityExportBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ExportActivity : AppCompatActivity() {
    private lateinit var binding: ActivityExportBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityExportBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnDoExport.setOnClickListener {
            exportGrnData()
        }

        binding.btnClearData.setOnClickListener {
            clearScannedData()
        }
    }

    private fun exportGrnData() {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val db = AppDatabase.getDatabase(this@ExportActivity)
                val scans = db.grnDao().getAllScannedItemsWithHeaders()
                
                if (scans.isEmpty()) {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(this@ExportActivity, "No GRN scans to export", Toast.LENGTH_SHORT).show()
                    }
                    return@launch
                }

                // Format: §"Reference","Barcode","Qty","Date"
                val stringBuilder = StringBuilder()
                val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
                
                scans.forEach { s ->
                    val dateStr = dateFormat.format(Date(s.date))
                    stringBuilder.append("§\"${s.reference}\",\"${s.barcode}\",\"${s.qty}\",\"$dateStr\"\n")
                }

                val fileName = "GRN_Export_${System.currentTimeMillis()}.txt"
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                val file = File(downloadsDir, fileName)
                
                val outputStream = FileOutputStream(file)
                outputStream.write(stringBuilder.toString().toByteArray())
                outputStream.close()

                withContext(Dispatchers.Main) {
                    binding.tvExportStatus.text = "Exported ${scans.size} items to:\n${file.absolutePath}"
                    binding.btnClearData.visibility = View.VISIBLE
                    Toast.makeText(this@ExportActivity, "Export Successful!", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@ExportActivity, "Export Error: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun clearScannedData() {
        lifecycleScope.launch(Dispatchers.IO) {
            val db = AppDatabase.getDatabase(this@ExportActivity)
            db.grnDao().deleteAllItems()
            db.grnDao().deleteAllHeaders()
            
            withContext(Dispatchers.Main) {
                binding.tvExportStatus.text = "All scan data cleared."
                binding.btnClearData.visibility = View.GONE
                Toast.makeText(this@ExportActivity, "Data Cleared", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
