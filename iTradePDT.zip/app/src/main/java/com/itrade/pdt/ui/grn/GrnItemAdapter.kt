package com.itrade.pdt.ui.grn

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.itrade.pdt.data.entity.GRNItem
import com.itrade.pdt.databinding.ItemGrnRowBinding

data class GrnItemDisplay(
    val item: GRNItem,
    val name: String
)

class GrnItemAdapter(
    private val items: MutableList<GrnItemDisplay>,
    private val onRemove: (Int) -> Unit
) : RecyclerView.Adapter<GrnItemAdapter.ViewHolder>() {

    class ViewHolder(val binding: ItemGrnRowBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemGrnRowBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val displayItem = items[position]
        holder.binding.tvBarcode.text = displayItem.item.barcode
        holder.binding.tvItemName.text = displayItem.name
        holder.binding.tvQty.text = displayItem.item.qty.toString()
        
        holder.binding.btnRemove.setOnClickListener {
            onRemove(position)
        }
    }

    override fun getItemCount() = items.size
}
