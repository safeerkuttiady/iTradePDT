package com.itrade.pdt.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "grn_headers")
data class GRNHeader(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val date: Long,
    val reference: String
)
