package com.itrade.pdt.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class Product(
    @PrimaryKey val barcode: String,
    val name: String,
    val cost_price: Double,
    val selling_price: Double
)
