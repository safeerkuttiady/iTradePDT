package com.itrade.pdt.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.itrade.pdt.data.entity.GRNHeader
import com.itrade.pdt.data.entity.GRNItem

@Dao
interface GRNDao {
    @Insert
    suspend fun insertHeader(header: GRNHeader): Long

    @Insert
    suspend fun insertItems(items: List<GRNItem>)

    @Query("SELECT * FROM grn_headers ORDER BY date DESC")
    suspend fun getAllHeaders(): List<GRNHeader>

    @Query("SELECT * FROM grn_items WHERE grnId = :grnId")
    suspend fun getItemsForGRN(grnId: Int): List<GRNItem>

    @Query("SELECT i.*, h.reference, h.date FROM grn_items i INNER JOIN grn_headers h ON i.grnId = h.id")
    suspend fun getAllScannedItemsWithHeaders(): List<GRNItemWithHeader>

    @Query("DELETE FROM grn_headers")
    suspend fun deleteAllHeaders()

    @Query("DELETE FROM grn_items")
    suspend fun deleteAllItems()
}

data class GRNItemWithHeader(
    val id: Int,
    val grnId: Int,
    val barcode: String,
    val qty: Double,
    val reference: String,
    val date: Long
)
