package com.itrade.pdt.ui.main

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.itrade.pdt.databinding.ActivityMainBinding
import com.itrade.pdt.ui.export.ExportActivity
import com.itrade.pdt.ui.grn.GrnActivity
import com.itrade.pdt.ui.importing.ImportActivity

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnImport.setOnClickListener {
            startActivity(Intent(this, ImportActivity::class.java))
        }

        binding.btnGRN.setOnClickListener {
            startActivity(Intent(this, GrnActivity::class.java))
        }

        binding.btnExport.setOnClickListener {
            startActivity(Intent(this, ExportActivity::class.java))
        }
    }
}
