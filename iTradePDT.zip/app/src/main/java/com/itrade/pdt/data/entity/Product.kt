package com.itrade.pdt.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class Product(
    @PrimaryKey val barcode: String,
    val name: String,
    val costPrice: Double,
    val sellingPrice: Double
)
