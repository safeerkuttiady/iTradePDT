package com.itrade.pdt

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = android.widget.LinearLayout(this)
        layout.orientation = android.widget.LinearLayout.VERTICAL
        layout.setPadding(20,20,20,20)

        val btnImport = Button(this)
        btnImport.text = "Import Items"

        val btnGRN = Button(this)
        btnGRN.text = "GRN Entry"

        val btnExport = Button(this)
        btnExport.text = "Export Data"

        layout.addView(btnImport)
        layout.addView(btnGRN)
        layout.addView(btnExport)

        setContentView(layout)

        btnImport.setOnClickListener {
            startActivity(Intent(this, ImportActivity::class.java))
        }
    }
}
