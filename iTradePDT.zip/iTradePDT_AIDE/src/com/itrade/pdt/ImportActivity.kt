package com.itrade.pdt

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.*
import java.io.BufferedReader
import java.io.InputStreamReader

class ImportActivity : Activity() {

    private val PICK_FILE = 1001
    private val list = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL

        val btnSelect = Button(this)
        btnSelect.text = "Select File"

        val listView = ListView(this)

        val btnSave = Button(this)
        btnSave.text = "Save (Preview Only)"

        layout.addView(btnSelect)
        layout.addView(listView)
        layout.addView(btnSave)

        setContentView(layout)

        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, list)
        listView.adapter = adapter

        btnSelect.setOnClickListener {
            val intent = Intent(Intent.ACTION_GET_CONTENT)
            intent.type = "*/*"
            startActivityForResult(intent, PICK_FILE)
        }

        btnSave.setOnClickListener {
            Toast.makeText(this, "Preview loaded (DB comes next)", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == PICK_FILE && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            readFile(uri)
        }
    }

    private fun readFile(uri: Uri) {
        list.clear()

        val inputStream = contentResolver.openInputStream(uri)
        val reader = BufferedReader(InputStreamReader(inputStream))

        var line: String?
        var count = 0

        while (reader.readLine().also { line = it } != null && count < 20) {
            val parsed = parseLine(line!!)
            if (parsed != null) {
                list.add(parsed)
                count++
            }
        }
    }

    private fun parseLine(line: String): String? {
        return try {
            val clean = line.replace("§", "")
            val parts = clean.split("\",\"")

            val barcode = parts[0].replace("\"", "")
            val name = parts[1]
            val cost = parts[2]
            val price = parts[3].replace("\"", "")

            " |  |  | "
        } catch (e: Exception) {
            null
        }
    }
}
