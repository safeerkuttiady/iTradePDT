# iTradePDT - Windows Build Instructions

This project is configured to be built using the command line on Windows.

## 1. Prerequisites
- **Java JDK 17:** Ensure Java 17 is installed and added to your System PATH.
- **Android SDK:** You must have the Android SDK installed on your PC.

## 2. Setup (One-time)
Open the project folder and create a file named `local.properties`. 
Add the following line, replacing the path with your actual Android SDK path:

sdk.dir=C:/Users/YOUR_USER_NAME/AppData/Local/Android/Sdk

(Note: Use forward slashes '/' or double backslashes '\\' in the path).

## 3. Accepting Licenses
If you haven't used this SDK version before, you may need to accept licenses. 
Open CMD in the project folder and run:
"%ANDROID_HOME%/cmdline-tools/latest/bin/sdkmanager.bat" --licenses

## 4. Building the APK
To build the app, open the Command Prompt (CMD) in this directory and run:

gradlew.bat assembleDebug

## 5. Finding the App
Once the build is successful, your APK file will be located at:
\app\build\outputs\apk\debug\app-debug.apk

## Project Features included in this build:
- Master Product Import (CSV/TXT with preview).
- GRN Scanning (Barcode scanning + list view with removal).
- Transaction Export (Scanned data to TXT format).
