#!/data/data/com.termux/files/usr/bin/bash

echo "🚀 Creating AIDE-compatible iTradePDT..."

mkdir -p iTradePDT_AIDE
cd iTradePDT_AIDE || exit

# ---------------- PROJECT CONFIG ----------------

cat > AndroidManifest.xml <<EOF
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.itrade.pdt">

    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE"/>

    <application
        android:allowBackup="true"
        android:label="iTradePDT"
        android:theme="@android:style/Theme.Holo.Light.NoActionBar">

        <activity android:name=".MainActivity">
            <intent-filter>
                <action android:name="android.intent.action.MAIN"/>
                <category android:name="android.intent.category.LAUNCHER"/>
            </intent-filter>
        </activity>

        <activity android:name=".ImportActivity"/>

    </application>
</manifest>
EOF

# ---------------- SRC ----------------

mkdir -p src/com/itrade/pdt

# MainActivity
cat > src/com/itrade/pdt/MainActivity.kt <<EOF
package com.itrade.pdt

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = android.widget.LinearLayout(this)
        layout.orientation = android.widget.LinearLayout.VERTICAL
        layout.setPadding(20,20,20,20)

        val btnImport = Button(this)
        btnImport.text = "Import Items"

        val btnGRN = Button(this)
        btnGRN.text = "GRN Entry"

        val btnExport = Button(this)
        btnExport.text = "Export Data"

        layout.addView(btnImport)
        layout.addView(btnGRN)
        layout.addView(btnExport)

        setContentView(layout)

        btnImport.setOnClickListener {
            startActivity(Intent(this, ImportActivity::class.java))
        }
    }
}
EOF

# ImportActivity
cat > src/com/itrade/pdt/ImportActivity.kt <<EOF
package com.itrade.pdt

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.*
import java.io.BufferedReader
import java.io.InputStreamReader

class ImportActivity : Activity() {

    private val PICK_FILE = 1001
    private val list = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL

        val btnSelect = Button(this)
        btnSelect.text = "Select File"

        val listView = ListView(this)

        val btnSave = Button(this)
        btnSave.text = "Save (Preview Only)"

        layout.addView(btnSelect)
        layout.addView(listView)
        layout.addView(btnSave)

        setContentView(layout)

        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, list)
        listView.adapter = adapter

        btnSelect.setOnClickListener {
            val intent = Intent(Intent.ACTION_GET_CONTENT)
            intent.type = "*/*"
            startActivityForResult(intent, PICK_FILE)
        }

        btnSave.setOnClickListener {
            Toast.makeText(this, "Preview loaded (DB comes next)", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == PICK_FILE && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            readFile(uri)
        }
    }

    private fun readFile(uri: Uri) {
        list.clear()

        val inputStream = contentResolver.openInputStream(uri)
        val reader = BufferedReader(InputStreamReader(inputStream))

        var line: String?
        var count = 0

        while (reader.readLine().also { line = it } != null && count < 20) {
            val parsed = parseLine(line!!)
            if (parsed != null) {
                list.add(parsed)
                count++
            }
        }
    }

    private fun parseLine(line: String): String? {
        return try {
            val clean = line.replace("§", "")
            val parts = clean.split("\",\"")

            val barcode = parts[0].replace("\"", "")
            val name = parts[1]
            val cost = parts[2]
            val price = parts[3].replace("\"", "")

            "$barcode | $name | $cost | $price"
        } catch (e: Exception) {
            null
        }
    }
}
EOF

echo "✅ AIDE Project Ready!"
echo "📂 Open iTradePDT_AIDE folder inside AIDE"
